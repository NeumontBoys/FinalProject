package edu.neumont.oop.Model;

import edu.neumont.oop.Controller.Die;
import edu.neumont.oop.View.Output;

public abstract class InteractPerson {
    //Properties
    private String name;
    private int hp;
    private int armorClass;
    private boolean isDead = false;

    //Called Classes
    Output output = new Output();
    Die die = new Die();

    // Name Getter & Setter
    public String getName(){
        return name;
    }
    public void setName(String name){
        this.name = name;
    }

    // HP Getter & Setter
    public int getHp(){
        return hp;
    }
    public void setHp(int hp){
        if (hp <= 0){
            this.hp = 0;
            setDead(true);
        }else{
            this.hp = hp;
        }
    }

    // Armor Class Getter & Setter
    public int getArmorClass(){
        return armorClass;
    }
    public void setArmorClass(int armorClass){
        this.armorClass = armorClass;
    }

    // Death Methods
    public boolean isDead() {
        return isDead;
    }
    public void setDead(boolean dead) {
        isDead = dead;
    }

    // General Methods
    public void attack(InteractPerson target){

    }

    public void rollAndDealDamage(InteractPerson target, int roll){
        output.display(getName() + " strikes " + target.getName() + " for " + roll + " damage!");
        target.setHp(target.getHp() - roll);
    }

    public void critAttack(InteractPerson target){}

    public void rollToHit(InteractPerson target){
        int roll = die.roll(1, 20);
        if (roll >= target.getArmorClass()){
            output.display(getName() + " successfully hits " + target.getName() + "!");
            attack(target);
        } else{
            output.display(getName() + " missed!");
        }
    }

    public void rollToHeal(){
        int roll = die.roll(1, 20);
        if(roll == 20){
            output.display(getName() + " heals critically with a nat 20! ");
            critHeal();
        }else if (roll > 10){
            output.display(getName() + " heals successfully with a roll of " + roll + ". ");
            heal();
        }else{
            output.display(getName() + " fails to heal with a roll of " + roll + ". ");
        }
    }

    public void heal(){}
    public void critHeal(){}
}