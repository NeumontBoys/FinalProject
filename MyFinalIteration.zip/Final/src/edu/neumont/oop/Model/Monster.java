package edu.neumont.oop.Model;

import edu.neumont.oop.Controller.Die;

public class Monster extends InteractPerson{
    //Called Class
    private final Die die = new Die();

    //Constructor
    public Monster(){};
    public Monster(String name, int hp, int armorClass){
        setName(name);
        setHp(hp);
        setArmorClass(armorClass);
    }

    @Override
    public void attack(InteractPerson target) {
        switch (getName()){
            case "Skeleton", "Goblin", "Mimic" -> super.rollAndDealDamage(target, die.roll(1, 8));
            case "Slime" -> super.rollAndDealDamage(target, die.roll(2, 2));
            case "Zombie" -> super.rollAndDealDamage(target, die.roll(2, 5));
            case "Troll" -> super.rollAndDealDamage(target, die.roll(2, 6));
            case "Ogre", "Bug Bear", "Amalgamate" -> super.rollAndDealDamage(target, die.roll(2, 8));
            case "Champion Minotaur" -> super.rollAndDealDamage(target, die.roll(3, 8));
            case "The Duck" -> super.rollAndDealDamage(target, die.roll(5, 20));
            case "Wisp" -> super.rollAndDealDamage(target, die.roll(1, 1));
            case "Bat" -> super.rollAndDealDamage(target, die.roll(1, 6));
            case "Mummy", "Hobgoblin" -> super.rollAndDealDamage(target, die.roll(1, 10));
            case "The Rat King" -> super.rollAndDealDamage(target, die.roll(3, 10));
            case "Shadow Brute" -> super.rollAndDealDamage(target, die.roll(2, 20));
            case "Ghost" -> super.rollAndDealDamage(target, die.roll(1, 4));
            case "Construct", "Banshee" -> super.rollAndDealDamage(target, die.roll(2, 10));
            case "Lich" -> super.rollAndDealDamage(target, die.roll(3, 12));
        }
    }

    @Override
    public void critAttack(InteractPerson target) {
        switch (getName()){
            case "Skeleton", "Goblin", "Mimic" -> super.rollAndDealDamage(target, die.roll(1, 8) * 2);
            case "Slime" -> super.rollAndDealDamage(target, die.roll(2, 2)  * 2);
            case "Zombie" -> super.rollAndDealDamage(target, die.roll(2, 5)  * 2);
            case "Troll" -> super.rollAndDealDamage(target, die.roll(2, 6)  * 2);
            case "Ogre", "Bug Bear", "Amalgamate" -> super.rollAndDealDamage(target, die.roll(2, 8)  * 2);
            case "Champion Minotaur" -> super.rollAndDealDamage(target, die.roll(3, 8)  * 2);
            case "The Duck" -> super.rollAndDealDamage(target, die.roll(5, 20)  * 2);
            case "Wisp" -> super.rollAndDealDamage(target, die.roll(1, 1)  * 2);
            case "Bat" -> super.rollAndDealDamage(target, die.roll(1, 6)  * 2);
            case "Mummy", "Hobgoblin" -> super.rollAndDealDamage(target, die.roll(1, 10)  * 2);
            case "The Rat King" -> super.rollAndDealDamage(target, die.roll(3, 10)  * 2);
            case "Shadow Brute" -> super.rollAndDealDamage(target, die.roll(2, 20)  * 2);
            case "Ghost" -> super.rollAndDealDamage(target, die.roll(1, 4)  * 2);
            case "Construct", "Banshee" -> super.rollAndDealDamage(target, die.roll(2, 10)  * 2);
            case "Lich" -> super.rollAndDealDamage(target, die.roll(3, 12)  * 2);
        }
    }

    @Override
    public void heal() {
        switch (getName()){
            case "Skeleton", "Slime", "Zombie", "Troll", "Wisp", "Bat", "Mimic", "Ghost", "Goblin" -> setHp(getHp() + die.roll(1, 4));
            case "Ogre", "Amalgamate", "Construct", "Banshee" -> setHp(getHp() + die.roll(1, 8));
            case "Champion Minotaur", "The Rat King", "Bug Bear" -> setHp(getHp() + die.roll(1, 6));
            case "The Duck" -> setHp(getHp() + die.roll(1, 20));
            case "Mummy", "Hobgoblin" -> setHp(getHp() + die.roll(1, 5));
            case "Shadow Brute" -> setHp(getHp() + die.roll(1, 12));
            case "Lich" -> setHp(getHp() + die.roll(1, 10));
        }
    }

    @Override
    public void critHeal() {
        switch (getName()){
            case "Skeleton", "Slime", "Zombie", "Troll", "Wisp", "Bat", "Mimic", "Ghost", "Goblin" -> setHp(getHp() + 4);
            case "Ogre", "Amalgamate", "Construct", "Banshee" -> setHp(getHp() + 8);
            case "Champion Minotaur", "The Rat King", "Bug Bear" -> setHp(getHp() + 6);
            case "The Duck" -> setHp(getHp() + 20);
            case "Mummy", "Hobgoblin" -> setHp(getHp() + 5);
            case "Shadow Brute" -> setHp(getHp() + 12);
            case "Lich" -> setHp(getHp() + 10);
        }
    }
}