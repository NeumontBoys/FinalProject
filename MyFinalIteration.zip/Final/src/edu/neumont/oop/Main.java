package edu.neumont.oop;

import edu.neumont.oop.Controller.Menu;

public class Main {
    public static void main(String[] args) {
        Menu menu = new Menu();
        menu.start();
    }
}