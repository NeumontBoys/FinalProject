package edu.neumont.oop.View;

public class Output {
    public void divider(){
        System.out.println("--------------------");
    }

    public String promptForName(){
        divider();
        return "Enter A Name For Your Character: ";
    }

    public void promptForRace(){
        divider();
        System.out.println("Choose A Race For Your Character: ");
    }

    public void promptForClass(){
        divider();
        System.out.println("Choose A Class For Your Character: ");
    }

    public void chooseARoom(){
        divider();
        System.out.println("Please Choose A Room To Enter: ");
    }

    public void chooseAMonster(){
        divider();
        System.out.println("Please Select A Monster: ");
    }

    public String[] attackOrHeal(){
        divider();
        return new String[]{"Attack!", "Heal Self"};
    }

    public String enterDungeonPrompt(){
        divider();
        return "Enter The Dungeon? (Y/N): ";
    }

    public String dungeonComplete(){
        divider();
        return "You've completed the dungeon! Try again? (Y/N): ";
    }

    public String playerDeath(){
        divider();
        return "You died! Try again? (Y/N): ";
    }

    public void gameOver(){
        divider();
        System.out.println("G A M E   O V E R ! ! !");
    }

    public void farewell(){
        divider();
        System.out.println("See ya' next time, adventurer.");
    }

    public void display(String text){
        System.out.println(text);
    }
}