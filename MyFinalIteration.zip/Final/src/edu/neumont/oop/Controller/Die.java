package edu.neumont.oop.Controller;

import lib.ConsoleIO;

import java.util.Random;

public class Die {
    //Called Classes
    private final Random random = new Random();

    //Roll method
    public int roll(int numOfDice, int numOfSides){
        return numOfDice * randomGenerator(1, numOfSides);
    }

    //Random Number Generator
    public int randomGenerator (int lowBound, int upBound){
        int randomNumber = random.nextInt((upBound - lowBound) + 1) + lowBound;
        return randomNumber;
    }
}