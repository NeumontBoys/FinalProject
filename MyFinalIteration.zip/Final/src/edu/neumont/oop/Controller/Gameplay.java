package edu.neumont.oop.Controller;

import edu.neumont.oop.Model.Character;
import edu.neumont.oop.Model.Dungeon;
import edu.neumont.oop.Model.InteractPerson;
import edu.neumont.oop.Model.Monster;
import edu.neumont.oop.View.Output;
import lib.ConsoleIO;

import java.util.ArrayList;

public class Gameplay {
    //Called Classes
    Output output = new Output();
    Dungeon dungeon = new Dungeon();

    //Properties
    Character player;

    public void startGame(){
        // will prompt user to enter dungeon (Y/N)?
        boolean loop = ConsoleIO.promptForBoolean(output.enterDungeonPrompt(), "Y", "N");
        // While the user agrees to enter the dungeon, they are contained in a loop
        while (loop) {
            while (player.getHp() > 0){
                if (!emptyDungeonCheck()) {
                    manageRoom();
                }
                // if the loop finds that the dungeon is empty, it will go from here
                else{
                    // Prompts to play again. If y, reruns this function. If n, ends game.
                    if(ConsoleIO.promptForBoolean(output.dungeonComplete(), "Y", "N")) {
                        dungeon = new Dungeon();
                        startGame();
                    }
                    // if the dungeon is empty, the loop can be broken.
                    loop = false;
                }
            }
            checkForPlayerDeath();
        }
    }

    //Methods to make the startGame method smaller
    private void manageRoom(){
        // if the dungeon IS NOT empty, then it will prompt for a room selection
        int room = enterRoom();
        while (!emptyRoomCheck(room)) {
            if (player.getHp() <= 0 ){
                break;
            }
            if (dungeon.getDungeon().get(room - 1).getMonsters().size() == 1 && getMonstersFromRoom(room).get(0).getHp() == 0){
                getMonstersFromRoom(room).remove(0);
            }
            // if the selected room IS NOT empty, combat will be initiated
            combat(player, room);
        }
    }

    private void checkForPlayerDeath(){
        if (player.getHp() <= 0){
            output.gameOver();
            if (characterDeath()){
                dungeon = new Dungeon();
                startGame();
            }
        }
    }

    // STRING[] FOR MENU PROMPTS
    public String[] roomsString(Dungeon dungeon){
        String[] rooms = new String[dungeon.getDungeon().size()];
        for (int i = 0; i < dungeon.getDungeon().size(); i++) {
            rooms[i] = ("Room " + (i + 1));
        }
        return rooms;
    }
    public String[] monstersString(int chosenRoom){
        String[] monsters = new String[getSizeOfMonstersInRoom(chosenRoom)];
        for (int i = 0; i < getSizeOfMonstersInRoom(chosenRoom); i++) {
            monsters[i] = getMonstersFromRoom(chosenRoom).get(i).getName();
        }
        return monsters;
    }

    // ARRAYLIST HELPERS
    public int getSizeOfMonstersInRoom(int room){
        return dungeon.getDungeon().get(room - 1).getMonsters().size();
    }
    public ArrayList<Monster> getMonstersFromRoom(int room){
        return dungeon.getDungeon().get(room - 1).getMonsters();
    }
    public Monster randomMonsterInRoom(int room){
        Die d = new Die();
        return getMonstersFromRoom(room).get(d.randomGenerator(0,getSizeOfMonstersInRoom(room) - 1));
    }
    private int chooseRoom(){
        output.chooseARoom();
        return ConsoleIO.promptForMenuSelection(roomsString(dungeon), false) + 1;
    }
    private Monster chooseMonsterInRoom(int room){
        while(!emptyRoom(room)){
            output.chooseAMonster();
            int monster = ConsoleIO.promptForMenuSelection(monstersString(room), false);
            return getMonstersFromRoom(room).get(monster);
        }
        return null;
    }

    // COMBAT METHOD
    public void attackOrHeal(InteractPerson attacker, InteractPerson target){
        int action = 0;
        if(attacker == player){
            action = ConsoleIO.promptForMenuSelection(output.attackOrHeal(), false) + 1;
        }else{
            Die d = new Die();
            action = d.randomGenerator(1,2);
        }
        switch (action){
            case 1 -> {
                attacker.rollToHit(target);
                output.display(target.getName() + ", HP: " + target.getHp() + "\n");
            }
            case 2 -> {
                attacker.rollToHeal();
                output.display(attacker.getName() + ", HP: " + attacker.getHp() + "\n");
            }
        }
    }
    public void combat(InteractPerson player, int room){
        int action = 1;
        switch (action){
            case 1:{
                attackOrHeal(player, chooseMonsterInRoom(room));
                checkMonsterDeath(room);
                action++;
            }
            case 2:{
                if (getSizeOfMonstersInRoom(room) <= 0){
                    break;
                }else {
                    attackOrHeal(randomMonsterInRoom(room), player);
                    action--;
                }
            }
        }
    }

    // HELPERS TO THE START FUNCTION
    // Upon Entering Dungeon, Player MUST choose a room
    public int enterRoom(){
        return chooseRoom();
    }

    // CHECK FUNCTIONS
    public boolean emptyRoomCheck(int room){
        if (getSizeOfMonstersInRoom(room) == 0){
            dungeon.getDungeon().remove(room - 1);
            return true;
        }
        return false;
    }
    public boolean emptyDungeonCheck(){
        return dungeon.getDungeon().size() == 0;
    }
    public boolean emptyRoom(int room){
        if(dungeon.getDungeon().size() > 0){
            if (dungeon.getDungeon().get(room - 1).getMonsters().size() == 0){
                dungeon.getDungeon().remove(room - 1);
                output.display("Room " + room + " has been cleared!");
                return true;
            }
        }
        return false;
    }
    public void checkMonsterDeath(int room){
        for (int i = 0; i < getSizeOfMonstersInRoom(room); i++) {
            if (getMonstersFromRoom(room).get(i).getHp() <= 0){
                getMonstersFromRoom(room).remove(i);
            }
        }
    }
    // COMPLETION OR DEATH

    public boolean characterDeath(){
        if (ConsoleIO.promptForBoolean(output.playerDeath(), "Y", "N")){
            return true;
        }
        return false;
    }
}