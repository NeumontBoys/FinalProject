package edu.neumont.oop;

import edu.neumont.oop.Controller.Gameplay;

public class Main {
    public static void main(String[] args) {
        Gameplay g = new Gameplay();
        g.start();
        g.farewell();
    }
}
