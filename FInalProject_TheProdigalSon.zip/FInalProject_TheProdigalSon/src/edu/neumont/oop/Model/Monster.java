package edu.neumont.oop.Model;

import lib.ConsoleIO;

public class Monster extends InteractPerson{

    // CONSTRUCTORS
    public Monster(){}
    public Monster(String name){
        super(name);
    }
    public Monster(String name, int hp, int armorClass){
        super(name, hp, armorClass);
    }

    private Die d = new Die();

    // ATTACK AND HEAL

    @Override
    public void attack(InteractPerson target) {
        switch (getName()){
            case "Skeleton" -> super.rollAndDealDamage(target, d.roll(1, 8));
            case "Slime" -> super.rollAndDealDamage(target, d.roll(2, 2));
            case "Zombie" -> super.rollAndDealDamage(target, d.roll(2, 5));
            case "Troll" -> super.rollAndDealDamage(target, d.roll(2, 6));
            case "Ogre" -> super.rollAndDealDamage(target, d.roll(2, 8));
            case "Champion Minotaur" -> super.rollAndDealDamage(target, d.roll(3, 8));
            case "The Duck" -> super.rollAndDealDamage(target, d.roll(5, 20));
            case "Wisp" -> super.rollAndDealDamage(target, d.roll(1, 1));
            case "Amalgamate" -> super.rollAndDealDamage(target, d.roll(2, 8));
            case "Bat" -> super.rollAndDealDamage(target, d.roll(1, 6));
            case "Mimic" -> super.rollAndDealDamage(target, d.roll(1, 8));
            case "Mummy" -> super.rollAndDealDamage(target, d.roll(1, 10));
            case "The Rat King" -> super.rollAndDealDamage(target, d.roll(3, 10));
            case "Shadow Brute" -> super.rollAndDealDamage(target, d.roll(2, 20));
            case "Ghost" -> super.rollAndDealDamage(target, d.roll(1, 4));
            case "Goblin" -> super.rollAndDealDamage(target, d.roll(1, 8));
            case "Hobgoblin" -> super.rollAndDealDamage(target, d.roll(1, 10));
            case "Bug Bear" -> super.rollAndDealDamage(target, d.roll(2, 8));
            case "Construct" -> super.rollAndDealDamage(target, d.roll(2, 10));
            case "Banshee" -> super.rollAndDealDamage(target, d.roll(2, 10));
            case "Lich" -> super.rollAndDealDamage(target, d.roll(3, 12));
        }
    }

    @Override
    public void critAttack(InteractPerson target) {
        switch (getName()){
            case "Skeleton" -> super.rollAndDealDamage(target, d.roll(1, 8) * 2);
            case "Slime" -> super.rollAndDealDamage(target, d.roll(2, 2)  * 2);
            case "Zombie" -> super.rollAndDealDamage(target, d.roll(2, 5)  * 2);
            case "Troll" -> super.rollAndDealDamage(target, d.roll(2, 6)  * 2);
            case "Ogre" -> super.rollAndDealDamage(target, d.roll(2, 8)  * 2);
            case "Champion Minotaur" -> super.rollAndDealDamage(target, d.roll(3, 8)  * 2);
            case "The Duck" -> super.rollAndDealDamage(target, d.roll(5, 20)  * 2);
            case "Wisp" -> super.rollAndDealDamage(target, d.roll(1, 1)  * 2);
            case "Amalgamate" -> super.rollAndDealDamage(target, d.roll(2, 8)  * 2);
            case "Bat" -> super.rollAndDealDamage(target, d.roll(1, 6)  * 2);
            case "Mimic" -> super.rollAndDealDamage(target, d.roll(1, 8)  * 2);
            case "Mummy" -> super.rollAndDealDamage(target, d.roll(1, 10)  * 2);
            case "The Rat King" -> super.rollAndDealDamage(target, d.roll(3, 10)  * 2);
            case "Shadow Brute" -> super.rollAndDealDamage(target, d.roll(2, 20)  * 2);
            case "Ghost" -> super.rollAndDealDamage(target, d.roll(1, 4)  * 2);
            case "Goblin" -> super.rollAndDealDamage(target, d.roll(1, 8)  * 2);
            case "Hobgoblin" -> super.rollAndDealDamage(target, d.roll(1, 10)  * 2);
            case "Bug Bear" -> super.rollAndDealDamage(target, d.roll(2, 8)  * 2);
            case "Construct" -> super.rollAndDealDamage(target, d.roll(2, 10)  * 2);
            case "Banshee" -> super.rollAndDealDamage(target, d.roll(2, 10)  * 2);
            case "Lich" -> super.rollAndDealDamage(target, d.roll(3, 12)  * 2);
        }
    }

    @Override
    public void heal() {
        switch (getName()){
            case "Skeleton" -> setHp(getHp() + d.roll(1, 4));
            case "Slime" -> setHp(getHp() + d.roll(1, 4));
            case "Zombie" -> setHp(getHp() + d.roll(1, 4));
            case "Troll" -> setHp(getHp() + d.roll(1, 4));
            case "Ogre" -> setHp(getHp() + d.roll(1, 8));
            case "Champion Minotaur" -> setHp(getHp() + d.roll(1, 6));
            case "The Duck" -> setHp(getHp() + d.roll(1, 20));
            case "Wisp" -> setHp(getHp() + d.roll(1, 4));
            case "Amalgamate" -> setHp(getHp() + d.roll(1, 8));
            case "Bat" -> setHp(getHp() + d.roll(1, 4));
            case "Mimic" -> setHp(getHp() + d.roll(1, 4));
            case "Mummy" -> setHp(getHp() + d.roll(1, 5));
            case "The Rat King" -> setHp(getHp() + d.roll(1, 6));
            case "Shadow Brute" -> setHp(getHp() + d.roll(1, 12));
            case "Ghost" -> setHp(getHp() + d.roll(1, 4));
            case "Goblin" -> setHp(getHp() + d.roll(1, 4));
            case "Hobgoblin" -> setHp(getHp() + d.roll(1, 5));
            case "Bug Bear" -> setHp(getHp() + d.roll(1, 6));
            case "Construct" -> setHp(getHp() + d.roll(1, 8));
            case "Banshee" -> setHp(getHp() + d.roll(1, 8));
            case "Lich" -> setHp(getHp() + d.roll(1, 10));
        }
    }

    @Override
    public void critHeal() {
        switch (getName()){
            case "Skeleton" -> setHp(getHp() + 4);
            case "Slime" -> setHp(getHp() + 4);
            case "Zombie" -> setHp(getHp() + 4);
            case "Troll" -> setHp(getHp() + 4);
            case "Ogre" -> setHp(getHp() + 8);
            case "Champion Minotaur" -> setHp(getHp() + 6);
            case "The Duck" -> setHp(getHp() + 20);
            case "Wisp" -> setHp(getHp() + 4);
            case "Amalgamate" -> setHp(getHp() + 8);
            case "Bat" -> setHp(getHp() + 4);
            case "Mimic" -> setHp(getHp() + 4);
            case "Mummy" -> setHp(getHp() + 5);
            case "The Rat King" -> setHp(getHp() + 6);
            case "Shadow Brute" -> setHp(getHp() + 12);
            case "Ghost" -> setHp(getHp() + 4);
            case "Goblin" -> setHp(getHp() + 4);
            case "Hobgoblin" -> setHp(getHp() + 5);
            case "Bug Bear" -> setHp(getHp() + 6);
            case "Construct" -> setHp(getHp() + 8);
            case "Banshee" -> setHp(getHp() + 8);
            case "Lich" -> setHp(getHp() + 10);
        }
    }
}
