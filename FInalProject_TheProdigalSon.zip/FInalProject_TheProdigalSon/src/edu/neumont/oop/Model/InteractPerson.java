package edu.neumont.oop.Model;

import lib.ConsoleIO;

public abstract class InteractPerson {

    private String name;
    private int hp;
    private int armorClass;
    private Die d = new Die();

    public InteractPerson(){}
    public InteractPerson(String name){
        setName(name);
    }
    public InteractPerson(String name, int hp, int armorClass){
        setName(name);
        setHp(hp);
        setArmorClass(armorClass);
    }

    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }

    public int getHp() {
        return hp;
    }
    public void setHp(int hp) {
        if (hp <= 0){
            this.hp = 0;
        }else {
        this.hp = hp;
        }
    }

    public int getArmorClass() {
        return armorClass;
    }
    public void setArmorClass(int armorClass) {
        this.armorClass = armorClass;
    }

    public void attack(InteractPerson target){
        ConsoleIO.display("bing bong");
    }
    public void rollAndDealDamage(InteractPerson target, int roll){
        ConsoleIO.display(getName() + " strikes " + target.getName() + " for " + roll + " damage!");
        target.setHp(target.getHp() - roll);
    }


    public void critAttack(InteractPerson target){
        ConsoleIO.display("oof");
    }

    public void rollToHit(InteractPerson target){
        int roll = d.roll(1, 20);
        if (roll == 20){
            ConsoleIO.display(getName() + " strikes critically with a nat 20!");
            critAttack(target);
        }else if (roll >= target.getArmorClass()){
            ConsoleIO.display(getName() + " landed a strike with a roll of " + roll + ". ");
            attack(target);
        }else{
            ConsoleIO.display(getName() + " missed with a roll of " + roll + ". ");
        }
    }
    public void rollToHeal(){
        int roll = d.roll(1, 20);
        if(roll == 20){
            ConsoleIO.display(getName() + " heals critically with a nat 20! ");
            critHeal();
        }else if (roll > 10){
            ConsoleIO.display(getName() + " heals successfully with a roll of " + roll + ". ");
            heal();
        }else{
            ConsoleIO.display(getName() + " fails to heal with a roll of " + roll + ". ");
        }
    }

    public void heal(){}
    public void critHeal(){}
}
