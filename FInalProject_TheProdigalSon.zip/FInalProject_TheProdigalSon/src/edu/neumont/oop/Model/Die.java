package edu.neumont.oop.Model;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.Random;

public class Die {

    //Properties

    private final Random random = new Random();

    //Roll methods
    public int roll(int numOfDice, int numOfSides){
        return numOfDice * randomGenerator(1, numOfSides);
    }

    //Random Number Generator
    public int randomGenerator (int lowBound, int upBound){
        int randomNumber = random.nextInt((upBound - lowBound) + 1) + lowBound;
        return randomNumber;
    }
}
