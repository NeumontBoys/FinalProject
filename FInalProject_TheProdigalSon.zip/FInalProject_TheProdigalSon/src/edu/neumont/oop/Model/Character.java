package edu.neumont.oop.Model;

import lib.ConsoleIO;

public class Character extends InteractPerson{

    // RACES AND CLASSES
    private final String[] playerClasses = {"Wizard", "Rogue", "Sorcerer", "Barbarian", "Bard", "Archer", "Cleric", "Druid", "Warrior", "Mage"};
    private final String[] playerRaces = {"Human", "Troll", "Grung", "Demon", "Elf", "burb", "Dryad", "Centaur", "Dwarf", "Halfling"};

    // VARIABLES
    private String playerClass;
    private String playerRace;
    private int classValue;
    private int raceValue;
    private Die d = new Die();

    // CONSTRUCTORS
    public Character(String name){
        super(name);
        setHp(55);
        setArmorClass(10);
    }

    // GETTERS FOR ARRAYS
    public String[] getPlayerClasses() {
        return playerClasses;
    }
    public String[] getPlayerRaces() {
        return playerRaces;
    }

    // GETTERS AND SETTERS FOR CLASS
    public String getPlayerClass() {
        return playerClass;
    }
    public void setPlayerClass(int playerClass) {
        this.playerClass = getPlayerClasses()[playerClass];
    }
    public void classBasedHealth(){
        switch (getClassValue()){
            case 1 -> setHp(getHp() - 10);
            case 2 -> setHp(getHp() - 15);
            case 3 -> setHp(getHp() - 10);
            case 4 -> setHp(getHp() + 15);
            case 5 -> setHp(getHp() + 90);
            case 6 -> setHp(getHp() - 5);
            case 7 -> setHp(getHp() + 5);
            case 8 -> setHp(getHp() - 10);
            case 9 -> setHp(getHp() + 10);
            case 10-> setHp(getHp() - 10);
        }
    }

    public int getClassValue() {
        return classValue;
    }
    public void setClassValue(int classValue) {
        this.classValue = classValue;
        setPlayerClass(getClassValue());
        this.classValue++;
        classBasedHealth();
    }

    // GETTERS AND SETTERS FOR RACE
    public String getPlayerRace() {
        return playerRace;
    }
    public void setPlayerRace(int playerRace) {
        this.playerRace = getPlayerRaces()[playerRace];
    }
    public void raceBasedArmor(){
        switch (getRaceValue()){
            case 1 -> setArmorClass(getArmorClass());
            case 2 -> setArmorClass(getArmorClass() - 2);
            case 3 -> setArmorClass(getArmorClass() + 3);
            case 4 -> setArmorClass(getArmorClass() + 10);
            case 5 -> setArmorClass(getArmorClass() - 3);
            case 6 -> setArmorClass(getArmorClass() + 11);
            case 7 -> setArmorClass(getArmorClass() - 5);
            case 8 -> setArmorClass(getArmorClass() - 8);
            case 9 -> setArmorClass(getArmorClass() + 5);
            case 10-> setArmorClass(getArmorClass() + 4);
        }
    }

    public int getRaceValue() {
        return raceValue;
    }
    public void setRaceValue(int raceValue) {
        this.raceValue = raceValue;
        setPlayerRace(getRaceValue());
        this.raceValue++;
        raceBasedArmor();
    }

    // ATTACK AND HEAL
    @Override
    public void attack(InteractPerson target){
            switch (getClassValue()){
                case 1 -> {super.rollAndDealDamage(target, d.roll(2, 8));}
                case 2 -> {super.rollAndDealDamage(target, d.roll(3, 8));}
                case 3 -> {super.rollAndDealDamage(target, d.roll(3, 6)); }
                case 4 -> {super.rollAndDealDamage(target, d.roll(2, 12)); }
                case 5 -> {super.rollAndDealDamage(target, d.roll(4, 8)); }
                case 6 -> {super.rollAndDealDamage(target, d.roll(2, 10)); }
                case 7 -> {super.rollAndDealDamage(target, d.roll(1, 8)); }
                case 8 -> {super.rollAndDealDamage(target, d.roll(2, 4)); }
                case 9 -> {super.rollAndDealDamage(target, d.roll(3, 10)); }
                case 10-> {super.rollAndDealDamage(target, d.roll(4, 4)); }
            }
    }
    @Override
    public void critAttack(InteractPerson target){
        switch (getClassValue()){
            case 1 -> {super.rollAndDealDamage(target,d.roll(2, 8) * 2);}
            case 2 -> {super.rollAndDealDamage(target,d.roll(3, 8) * 2);}
            case 3 -> {super.rollAndDealDamage(target,d.roll(3, 6) * 2);}
            case 4 -> {super.rollAndDealDamage(target,d.roll(2, 12)* 2);}
            case 5 -> {super.rollAndDealDamage(target,d.roll(4, 8) * 2);}
            case 6 -> {super.rollAndDealDamage(target,d.roll(2, 10)* 2);}
            case 7 -> {super.rollAndDealDamage(target,d.roll(1, 8) * 2);}
            case 8 -> {super.rollAndDealDamage (target,d.roll(2, 4) * 2);}
            case 9 -> {super.rollAndDealDamage (target,d.roll(3, 10)* 2);}
            case 10-> {super.rollAndDealDamage (target,d.roll(4, 4) * 2);}
        }
    }

    @Override
    public void heal() {
        switch (getRaceValue()){
            case 1 -> setHp(getHp() + d.roll(1, 8));
            case 2 -> setHp(getHp() + d.roll(2, 6));
            case 3 -> setHp(getHp() + d.roll(2, 4));
            case 4 -> setHp(getHp() + d.roll(5, 10));
            case 5 -> setHp(getHp() + d.roll(3, 4));
            case 6 -> setHp(getHp() + d.roll(10, 20));
            case 7 -> setHp(getHp() + d.roll(5, 6));
            case 8 -> setHp(getHp() + d.roll(4, 8));
            case 9 -> setHp(getHp() + d.roll(2, 8));
            case 10-> setHp(getHp() + d.roll(1, 20));
        }
    }

    @Override
    public void critHeal() { // set to max value
        switch (getRaceValue()){
            case 1 -> setHp(getHp() + 8);
            case 2 -> setHp(getHp() + 12);
            case 3 -> setHp(getHp() + 8);
            case 4 -> setHp(getHp() + 50);
            case 5 -> setHp(getHp() + 12);
            case 6 -> setHp(getHp() + 200);
            case 7 -> setHp(getHp() + 30);
            case 8 -> setHp(getHp() + 32);
            case 9 -> setHp(getHp() + 16);
            case 10-> setHp(getHp() + 20);
        }
    }
}
