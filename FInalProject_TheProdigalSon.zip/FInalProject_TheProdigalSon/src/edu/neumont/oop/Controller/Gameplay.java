package edu.neumont.oop.Controller;

import edu.neumont.oop.Model.*;
import edu.neumont.oop.Model.Character;
import edu.neumont.oop.View.Menu;
import lib.ConsoleIO;

import java.util.ArrayList;

public class Gameplay {

    PersonFactory pf = new PersonFactory();
    Menu m = new Menu();
    Dungeon dungeon = new Dungeon();

    // THE BIG RED BUTTON
    public void start(){
        // a variable for the user's character is established for local use
        Character user = characterCreator();
        // will prompt user to enter dungeon (Y/N)?
        ConsoleIO.display(m.divider());
        Boolean bLoop = enterDungeonBoolean();
        ConsoleIO.display(m.divider());
        // While the user agrees to enter the dungeon, they are contained in a loop
        while (bLoop) {
            while (user.getHp() > 0){
                if (!emptyDungeonCheck()) {
                    // if the dungeon IS NOT empty, then it will prompt for a room selection
                    int room = enterRoom();
                    ConsoleIO.display(m.divider());
                    while (!emptyRoomCheck(room)) {
                        if (user.getHp() <= 0 ){
                            break;
                        }
                        if (dungeon.getDungeon().get(room - 1).getMonsters().size() == 1 && getMonstersFromRoom(room).get(0).getHp() == 0){
                            getMonstersFromRoom(room).remove(0);
                        }
                        // if the selected room IS NOT empty, combat will be initiated
                        combat(user, room);
                    }
                }
                // if the loop finds that the dungeon is empty, it will go from here
                else{
                    // Prompts to play again. If y, reruns this function. If n, ends game.
                    if(ConsoleIO.promptForBoolean(m.dungeonComplete(), "Y", "N")) {
                        dungeon = new Dungeon();
                        start();
                    }
                    // if the dungeon is empty, the loop can be broken.
                    bLoop = false;
                }
            }
            if (user.getHp() <= 0){
                ConsoleIO.display(m.gameOver());
                if (characterDeath()){
                    dungeon = new Dungeon();
                    start();
                }else{
                    break;
                }
            }
        }
    }

    // STRING[] FOR MENU PROMPTS
    public String[] roomsString(Dungeon dungeon){
        String[] rooms = new String[dungeon.getDungeon().size()];
        for (int i = 0; i < dungeon.getDungeon().size(); i++) {
            rooms[i] = ("Room " + (i + 1));
        }
        return rooms;
    }
    public String[] monstersString(int chosenRoom){
        String[] monsters = new String[getSizeOfMonstersInRoom(chosenRoom)];
        for (int i = 0; i < getSizeOfMonstersInRoom(chosenRoom); i++) {
            monsters[i] = getMonstersFromRoom(chosenRoom).get(i).getName();
        }
        return monsters;
    }

    // ARRAYLIST HELPERS
    public int getSizeOfMonstersInRoom(int room){
        return dungeon.getDungeon().get(room - 1).getMonsters().size();
    }
    public ArrayList<Monster> getMonstersFromRoom(int room){
        return dungeon.getDungeon().get(room - 1).getMonsters();
    }
    public Monster randomMonsterInRoom(int room){
        Die d = new Die();
        return getMonstersFromRoom(room).get(d.randomGenerator(0,getSizeOfMonstersInRoom(room) - 1));
    }
    private int chooseRoom(){
        ConsoleIO.display(m.chooseARoom());
        int room = ConsoleIO.promptForMenuSelection(roomsString(dungeon), false) + 1;
        return room;
    }
    private Monster chooseMonsterInRoom(int room){
        while (!emptyRoom(room)){
            ConsoleIO.display(m.chooseAMonster());
            int monster = ConsoleIO.promptForMenuSelection(monstersString(room), false);
            ConsoleIO.display(m.divider());
            return getMonstersFromRoom(room).get(monster);
        }
        return null;
    }

    // COMBAT METHODS
    public void attackOrHeal(InteractPerson user, Monster target){
        int action = ConsoleIO.promptForMenuSelection(m.attackOrHeal(), false) + 1;
        switch (action){
            case 1 -> {
                ConsoleIO.display(m.divider());
                user.rollToHit(target);
                ConsoleIO.display(target.getName() + ", HP: " + target.getHp() + "\n" + m.divider());
            }
            case 2 -> {
                ConsoleIO.display(m.divider());
                user.rollToHeal();
                ConsoleIO.display(user.getName() + ", HP: " + user.getHp() + "\n" + m.divider());
            }
        }
    }
    public void attackOrHeal(InteractPerson monsterUser, InteractPerson Playertarget){
        Die d = new Die();
        int action = d.randomGenerator(1,2);
        switch (action){
            case 1 -> {
                monsterUser.rollToHit(Playertarget);
                ConsoleIO.display(Playertarget.getName() + ", HP: " + Playertarget.getHp() + "\n" + m.divider());
            }
            case 2 -> {
                monsterUser.rollToHeal();
                ConsoleIO.display(monsterUser.getName() + ", HP: " + monsterUser.getHp() + "\n" + m.divider());
            }
        }
    }
    public void combat(InteractPerson player, int room){
        int action = 1;
        switch (action){
            case 1:{
                attackOrHeal(player, chooseMonsterInRoom(room));
                checkMonsterDeath(room);
                action++;
            }
            case 2:{
                if (getSizeOfMonstersInRoom(room) <= 0){
                    break;
                }else {
                    attackOrHeal(randomMonsterInRoom(room), player);
                    action--;
                }
            }
        }
    }

    // HELPERS TO THE START FUNCTION
    // Creates player character to begin the game
    public Character characterCreator(){
        InteractPerson pc = pf.createCharacter();
        return (Character) pc;
    }
    // Establishes if player wants to enter dungeon
    public boolean enterDungeonBoolean(){
        return ConsoleIO.promptForBoolean(m.enterDungeonPrompt(), "Y", "N");
    }
    // Upon Entering Dungeon, Player MUST choose a room
    public int enterRoom(){
        return chooseRoom();
    }



    // CHECK FUNCTIONS
    public boolean emptyRoomCheck(int room){
        if (getSizeOfMonstersInRoom(room) == 0){
            dungeon.getDungeon().remove(room - 1);
            return true;
        }
        return false;
    }
    public boolean emptyDungeonCheck(){
        if (dungeon.getDungeon().size() == 0){
            return true;
        }
        return false;
    }
    public boolean emptyRoom(int room){
        if(dungeon.getDungeon().size() > 0){
            if (dungeon.getDungeon().get(room - 1).getMonsters().size() == 0){
                dungeon.getDungeon().remove(room - 1);
                ConsoleIO.display("Room " + room + " has been cleared!");
                return true;
            }
        }
        return false;
    }
    public void checkMonsterDeath(int room){
        for (int i = 0; i < getSizeOfMonstersInRoom(room); i++) {
            if (getMonstersFromRoom(room).get(i).getHp() <= 0){
                getMonstersFromRoom(room).remove(i);
            }
        }
    }
    // COMPLETION OR DEATH
    public void dungeonComplete(){

    }
    public boolean characterDeath(){
        if (ConsoleIO.promptForBoolean(m.playerDeath(), "Y", "N")){
            return true;
        }
        return false;
    }
    public void farewell(){
        ConsoleIO.display(m.farewell());
    }

}
